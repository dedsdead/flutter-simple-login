import 'package:flutter/material.dart';
import 'package:login_sqlite/routes/view_routes.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: RoutesApp.home,
      onGenerateRoute: RoutesApp.generateRoute,
      theme: ThemeData(
          primarySwatch: Colors.grey,
          secondaryHeaderColor: Colors.black,
          errorColor: Colors.pink),
    ),
  );
}
